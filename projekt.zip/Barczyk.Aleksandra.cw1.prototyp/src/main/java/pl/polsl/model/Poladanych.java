/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pl.polsl.model;
import java.time.LocalDate;

/**
 *
 * @author Student ETO-B 10
 */
public class Poladanych {
    Human human;
    LocalDate dane;
    int consumption;
    
  public Poladanych(Human human,LocalDate dane,int consumption){
      this.human=human;
      this.dane=dane;
      this.consumption=consumption;
   } 
}
public class Poladanych{
     Human h1=new Human("Julia","Abrahamczyk","female",17);
     Human h2=new Human("Jan","Kowalski","male",16);
     Human h3=new Human("Maria","Nowak","female",15);
      LocalDate dane1=LocalDate.now();
      LocalDate dane2=LocalDate.of(2023,11,15);
      LocalDate dane3=LocalDate.of(2024,12,13);
      LocalDate dane4=LocalDate.of(2025,11,15);
  }


