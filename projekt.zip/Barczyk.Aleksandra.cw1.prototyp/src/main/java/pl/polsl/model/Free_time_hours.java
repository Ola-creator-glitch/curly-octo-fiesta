/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pl.polsl.model;

/**
 *
 * @author Student ETO-B 10
 */
import java.util.*;

public class Free_time_hours{
    List<Double> X=new ArrayList<Double>();
    X.add(1);
    X.add(2.5);
    X.add(3.5);
    X.add(4.5);
    Iterator<Double>itr=X.iterator();
   
    }

