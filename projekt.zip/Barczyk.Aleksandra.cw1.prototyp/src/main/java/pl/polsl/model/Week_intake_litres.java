/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pl.polsl.model;

/**
 *
 * @author olaba
 */

import java.util.*;

public class Week_intake_litres {
    List<Double>Y=new ArrayList<Double>();
    Y.add(1.5);
    Y.add(5.0);
    Y.add(2.5);
    Y.add(4.5);
    Iterator<Double>itr=Y.iterator();
    
}
