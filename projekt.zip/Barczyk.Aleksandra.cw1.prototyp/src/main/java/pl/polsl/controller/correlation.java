/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pl.polsl.controller;

/**
 *
 * @author Student ETO-B 10
 */
import java.util.*;
class CFG
{
    static void printVector(ArrayList<Double> X)
    {
        for(double i:X)
            System.out.print(i+"");
        System.out.println();
    }
        static ArrayList<Double> rankify(ArrayList<Double> X)
        {
            int N=x.size();
            ArrayList<Double> Rank_X=new ArrayList<Double> ();
            for(int i=0;i<N;i++){
                Rank_X.add(0d);
                int r=1,s=1;
                for(int j=i+1;j<N;j++){
                    if(X.get(j)<X.get(i))
                        r++;
                    if(X.get(j)==X.get(i))
                        s++;
                }
                Rank_X.set(i,(r+(s-1)*0,5));
                }
            return Rank_X;
            }
        static double 
        correlationCoefficient(ArrayList<Double> X,ArrayList<Double> Y)
        {
            int n=X.size();
            double sum_X=0,sum_Y=0,sum_XY=0;
            double squareSum_X=0,squareSum_Y=0;
            for(int i=0;i<n;i++){
                sum_X=sum_X+X.get(i);
                sum_Y=sum_Y+Y.get(i);
                sum_XY=sum_XY+X.get(i)*Y.get(i);
                squareSum_X=squareSum_X+X.get(i)*X.get(i);
                squareSum_Y=squareSum_Y+Y.get(i)*Y.get(i);
            }
            double corr
            =(n*sum_XY-sum_X*sum_Y)
              /Math.sqrt(
              (n*squareSum_X-sum_X*sum_X)
              *(n*squareSum_Y-sum_Y*sum_Y));
            return corr;
        }
        public static void main(String[] args)
        {
        ArrayList<Double> X=new ArrayList<Double>(
        Arrays.asList(15d,18d,21d,15d,21d));
        ArrayList<Double>Y=new ArrayList<Double>(
        Arrays.asList(25d,25d,27d,27d,27d));
        ArrayList<Double> rank_x=rankify(X);
        ArrayList<Double> rank_y=rankify(Y);
        System.out.println("Rankings of X");
        printVector(rank_x);
        System.out.println("Vector Y");
        printVector(Y);
        System.out.println("Rankings of Y");
        printVector(rank_y);
        System.out.println("Spearman's Rank correlation:");
        System.out.println(
        correlationCoefficient(rank_x,rank_y));
            }
        }
        