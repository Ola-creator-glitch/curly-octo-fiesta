/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pl.polsl.model;

/**
 *
 * @author olaba
 */
public class weekend_alcohol_intake_and_student_age {
    double [][] table={
        {3.5,2.5,4.5},
        {6.0,7.5,5.5}
    };
    
    
}
